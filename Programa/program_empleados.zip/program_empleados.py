#Shelve 
import os # El módulo os en Python proporciona y expone los detalles y la funcionalidad del sistema operativo
import shelve # shelve implementa el almacenamiento persistente para objetos arbitrarios de Python que pueden ser serializados, usando una interfaz de programación similar a un diccionario.

def limpiar_pantalla():
    # Verificar el sistema operativo
    if os.name == 'nt':  # Para Windows
        os.system('cls')
    else:  # Para Unix/Linux/MacOS
        os.system('clear')
# CRUD

def crear_empleado(db): # C (Create Creación empleados)
    print("*"*18)
    print("* CREAR EMPLEADO *")
    print("*"*18)
    cedula = (input("Introduce la cedula: "))
    nombres = input("Introduce los nombres del empleado: ")
    apellidos = input("Introduce los apellidos del empleado: ")
    edad = int(input("Introduce la edad del empleado: "))
    cargo = input("Introduce el cargo del empleado: ")
    fecha_ing = input("Introduce la fecha de ingreso del empleado: ")
    eps = input("Introduce la eps del empleado: ")
    salario = float(input("Introduce el salario: "))
    tipo_de_contrato = input("Introduce el tipo de contrato del empleado: ")

    db[cedula]  = {
        'cedula': cedula,
        'nombres': nombres,
        'apellidos': apellidos,
        'edad': edad,
        'cargo': cargo,
        'fecha_ing': fecha_ing,
        'eps': eps,
        'salario': salario,
        'tipo_contrato': tipo_de_contrato    
    }
    limpiar_pantalla() #Limpiar Pantalla
    print(f"El empleado {nombres+' '+apellidos} con cedula {cedula} fue creado exitosamente")
    
 
def listar_empleados(db): #R (Read Listar empleados)
    print("*"*20)
    print("* LISTADO EMPLEADOS *")
    print("*"*20)
    for fila in db:
        empleado = db[fila]
        print("*"*30)
        print(f"Cedula: {empleado['cedula']}")
        print(f"Nombres: {empleado['nombres']}")
        print(f"Apellidos: {empleado['apellidos']}")      
        print(f"Edad: {empleado['edad']}") 
        print(f"Cargo: {empleado['cargo']}")  
        print(f"Fecha Ingreso: {empleado['fecha_ing']}")
        print(f"Eps: {empleado['eps']}")
        print(f"Salario: {empleado['salario']}")
        print(f"Tipo de contrato: {empleado['tipo_contrato']}")
        

def editar_campo_empleado(db): #U (Update Acualizacion de registros)
    print("*"*27)
    print("* EDITAR REGISTRO EMPLEADO *")
    print("*"*27)
    cedula = input("Ingrese la cédula del empleado a editar: ")
    if cedula in db:
        empleado = db[cedula]
        campo = input("Ingrese el nombre del campo a editar (nombres, apellidos, edad, cargo, fecha_ing, eps, salario, tipo_contrato): ")
        if campo in empleado:
            nuevo_valor = input(f"Ingrese el nuevo valor para {campo}: ")
            empleado[campo] = nuevo_valor
            db.sync()
            print(f"El campo {campo} se ha actualizado correctamente.")
        else:
            print(f"El campo {campo} no existe en el registro del empleado.")
    else:
        print(f"El usuario con cédula : {cedula} no fue encontrado")
        
"""        
def editar_empleado(db):
    print("*"*20)
    print("* EDITAR EMPLEADO *")
    print("*"*20)
    cedula = input("Ingrese la cedula del empleado a editar: ")
    if cedula in db:
        empleado = db[cedula]
        # Mostrar los datos actuales del empleado
        print(f"Datos actuales del empleado con cédula: {cedula}")
        for  clave, valor in empleado.items():
            print(f"{clave}: {valor}")
            
        # Solicitar nuevos datos con validación básica
        nombres = input("Ingrese los nuevos nombres del empleado: ")
        apellidos = input("Ingrese los nuevos apellidos del empleado: ")
        edad = input("Ingrese la nueva edad del empleado: ")
        cargo = input("Ingrese el nuevo cargo del empleado: ")
        fecha_ing = input("Ingrese la nueva fecha de ingreso del empleado: ")
        eps = input("Ingrese la nueva eps del empleado: ")
        salario = input("Ingrese el nuevo salario del empleado: ")
        tipo_contrato = input("Ingrese el nuevo tipo de contrato del empleado: ")
        
        # Actualizar los datos del empleado
        empleado['nombres'] = nombres
        empleado['apellidos'] = apellidos
        empleado['edad'] = edad
        empleado['cargo'] = cargo
        empleado['fecha_ing'] = fecha_ing
        empleado['eps'] = eps
        empleado['salario'] = salario
        empleado['tipo_contrato'] = tipo_contrato
        
        print("Datos del empleado actualizados correctamente.")
    else:
        print(f"El usuario con cedula : {cedula} no fue encontrado")
"""
        
def eliminar_empleado(db): #D (Delete Eliminación de registro)
    print("*"*20)
    print("* ELIMINAR EMPLEADO *")
    print("*"*20)
    cedula = input("Ingrese la cedula del empleado a eliminar: ")
    if cedula in db:
        del db[cedula]
        print("Empleado eliminado con exito")
    else:
        print(f"El usuario con cedula : {cedula} no fue encontrado")

if __name__ == "__main__":
    limpiar_pantalla()
    with shelve.open('database_empleados', 'w') as db:  #with reeemplaza shelve.open / shelve.close
        while True:
            print("="*30)
            print("Menu de opciones: ")
            print("1. Crear empleado ")
            print("2. Listar empleados")
            print("3. Editar empleado")
            print("4. Eliminar empleado")
            print("5. Salir del programa")
            print("="*30)
            opcion = input("Digita una opción del menu: ")
            if opcion == "1":
                crear_empleado(db)
            elif opcion == "2":
                listar_empleados(db)
            elif opcion == "3":
                editar_campo_empleado(db)
            elif opcion == "4":
                eliminar_empleado(db)
            elif opcion == "5":
                break
            else:
                print("Opción no válida, por favor digite una opción válida")